import React from 'react';

function App() {
  return (
    <div className="app">
      <h1>Legion Records</h1>
      <p>Welcome to the underground metal store for CDs, tapes, and vinyls.</p>
    </div>
  );
}

export default App;